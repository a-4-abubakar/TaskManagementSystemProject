﻿using System.ComponentModel.DataAnnotations;


namespace TaskManagementSystem.Controllers.Models
{
    public class User
    {

        public int Id { get; set; }

        [Required]
        public string FullName { get; set; } = string.Empty;

        [Required]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        public ICollection<UserRole> UserRoles { get; set; }
    }
}
