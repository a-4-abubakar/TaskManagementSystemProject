﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace TaskManagementSystem.Controllers
{
 
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {

        // Anyone logged in (Admin or User)
        [Authorize]
        [HttpGet("all")]
        public IActionResult AllUsers()
        {
            return Ok("Any authenticated user can access this");
        }

        // Only Admin
        [Authorize(Roles = "Admin")]
        [HttpGet("admin")]
        public IActionResult AdminOnly()
        {
            return Ok("Only ADMIN can access this");
        }

        // Only User
        [Authorize(Roles = "User")]
        [HttpGet("user")]
        public IActionResult UserOnly()
        {
            return Ok("Only USER can access this");
        }
    }
}
